package com.concretepage.service;

import java.util.List;
import java.util.Map;

import com.concretepage.entity.GroupCodeValues;

public interface IReferenceDataService {
	
	Map<String, List<GroupCodeValues>> getGroupCodeValues();
	
	List<GroupCodeValues> loadGroupCodeValues();

}

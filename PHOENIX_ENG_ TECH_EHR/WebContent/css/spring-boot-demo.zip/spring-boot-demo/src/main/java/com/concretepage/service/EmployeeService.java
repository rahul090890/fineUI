package com.concretepage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.concretepage.dao.IEmployeeDAO;
import com.concretepage.entity.Employee;

@Service
public class EmployeeService implements IEmployeeService {
	
	private final String DEFAULT_PASSWORD = "Phe0nix@HYD"; 

	@Autowired
	private IEmployeeDAO dao;
	
	@Override
	public List<Employee> getEmployees() {
		return dao.getEmployees();
	}

	@Override
	public void update(Employee employee) {
		dao.update(employee);
	}

	@Override
	public void create(Employee employee) {
		dao.create(employee);
	}

	@Override
	public String resetPassword(String employeeId) {
		dao.resetPassword(Integer.parseInt(employeeId), DEFAULT_PASSWORD);
		return DEFAULT_PASSWORD;
		
	}

	@Override
	public void delete(Employee employee) {
		dao.delete(employee);
		
	}

	@Override
	public List<Employee> getManagers() {
		return dao.getManagers();
	}

}

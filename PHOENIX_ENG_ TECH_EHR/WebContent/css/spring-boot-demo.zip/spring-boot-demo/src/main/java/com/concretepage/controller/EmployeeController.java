package com.concretepage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.concretepage.entity.Department;
import com.concretepage.entity.Employee;
import com.concretepage.service.IEmployeeService;
@CrossOrigin(maxAge = 3600)
@Controller
@RequestMapping("hr/employee")
public class EmployeeController {

	@Autowired
	private IEmployeeService service;
	
	@GetMapping("all")
	public ResponseEntity<List<Employee>> getAllEmployees() {
		List<Employee> list = service.getEmployees();
		return new ResponseEntity<List<Employee>>(list, HttpStatus.OK);
	}
	
	@GetMapping("managers")
	public ResponseEntity<List<Employee>> getManagers (){
		List<Employee> list = service.getManagers();
		return new ResponseEntity<List<Employee>>(list, HttpStatus.OK);
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@PostMapping("update/{employeeId}/{firstName}/{lastName}/{emailId}/{loginId}/{loginPassword}/{managerId}/{address}/{designation}/{employeeType}/{departmentId}/{employementStatus}")
	public ResponseEntity<Void> update(
			@PathVariable("employeeId") String employeeId,
			@PathVariable("firstName") String firstName,
			@PathVariable("lastName") String lastName,
			@PathVariable("emailId") String emailId,
			@PathVariable("loginId") String loginId,
			@PathVariable("loginPassword") String loginPassword,
			@PathVariable("managerId") String managerId,
			@PathVariable("address") String address,
			@PathVariable("designation") String designation,
			@PathVariable("employeeType") String employeeType,
			@PathVariable("departmentId") String departmentId,
			@PathVariable("employementStatus") String employementStatus
													
			) {
		Employee emp = new Employee();
		emp.setEmployeeId(Integer.parseInt(employeeId));
		emp.setFirstName(firstName);
		emp.setLastName(lastName);
		emp.setEmailId(emailId);
		emp.setLoginId(loginId);
		emp.setLoginPassword(loginPassword);
		Employee manager = new Employee();
		manager.setEmployeeId(Integer.parseInt(managerId));
		emp.setManager(manager);
		emp.setAddress(address);
		emp.setDesignation(designation);
		emp.setEmployeeType(employeeType);
		Department dept = new Department();
		dept.setDepartmentId(Integer.parseInt(departmentId));
		emp.setDepartment(dept);
		emp.setEmployementStatus(employementStatus);
		service.update(emp);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@PostMapping("create/{firstName}/{lastName}/{emailId}/{loginId}/{loginPassword}/{managerId}/{address}/{designation}/{employeeType}/{departmentId}/{employementStatus}")
	public ResponseEntity<Void> create(
			@PathVariable("firstName") String firstName,
			@PathVariable("lastName") String lastName,
			@PathVariable("emailId") String emailId,
			@PathVariable("loginId") String loginId,
			@PathVariable("loginPassword") String loginPassword,
			@PathVariable("managerId") String managerId,
			@PathVariable("address") String address,
			@PathVariable("designation") String designation,
			@PathVariable("employeeType") String employeeType,
			@PathVariable("departmentId") String departmentId,
			@PathVariable("employementStatus") String employementStatus
													
			) {
		Employee emp = new Employee();
		emp.setFirstName(firstName);
		emp.setLastName(lastName);
		emp.setEmailId(emailId);
		emp.setLoginId(loginId);
		emp.setLoginPassword(loginPassword);
		Employee manager = new Employee();
		manager.setEmployeeId(Integer.parseInt(managerId));
		emp.setManager(manager);
		emp.setAddress(address);
		emp.setDesignation(designation);
		emp.setEmployeeType(employeeType);
		Department dept = new Department();
		dept.setDepartmentId(Integer.parseInt(departmentId));
		emp.setDepartment(dept);
		emp.setEmployementStatus(employementStatus);
		
		service.create(emp);
		
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@PostMapping("resetPassword/{employeeId}")
	public ResponseEntity<Void> resetPassword(@PathVariable("employeeId") String employeeId) {
		service.resetPassword(employeeId);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@DeleteMapping("delete/{employeeId}")
	public ResponseEntity<Void> delete (@PathVariable("employeeId") String employeeId) {
		Employee emp = new Employee();
		emp.setEmployeeId(Integer.parseInt(employeeId));
		service.delete(emp);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	
		
											
										
}

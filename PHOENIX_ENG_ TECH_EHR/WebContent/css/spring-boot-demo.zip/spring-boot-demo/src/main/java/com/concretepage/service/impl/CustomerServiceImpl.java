package com.concretepage.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.concretepage.dao.ICustomerDAO;
import com.concretepage.entity.Customer;
import com.concretepage.service.ICustomerService;

@Service
public class CustomerServiceImpl implements ICustomerService{

	@Autowired
	private ICustomerDAO dao;
	
	@Override
	public List<Customer> getCustomers() {
		return dao.getCustomers();
	}

	@Override
	public List<Customer> findByName(String customerName) {
		return dao.findByName(customerName);
	}

	@Override
	public void update(Customer customer) {
		dao.update(customer);
		
	}

	@Override
	public void create(Customer customer) {
		dao.create(customer);
		
	}

	@Override
	public void delete(Customer customer) {
		dao.delete(customer);
		
	}

}

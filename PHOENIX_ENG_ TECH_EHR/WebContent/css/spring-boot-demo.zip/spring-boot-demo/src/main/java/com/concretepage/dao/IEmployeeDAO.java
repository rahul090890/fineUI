package com.concretepage.dao;

import java.util.List;

import com.concretepage.entity.Employee;

public interface IEmployeeDAO {

	List<Employee> getEmployees();
	
	List<Employee> getManagers();
	
	void update (Employee emp);
	
	void create (Employee emp);
	
	void resetPassword(int employeeId, String newPassword);
	
	void delete(Employee emp);
	
	
}

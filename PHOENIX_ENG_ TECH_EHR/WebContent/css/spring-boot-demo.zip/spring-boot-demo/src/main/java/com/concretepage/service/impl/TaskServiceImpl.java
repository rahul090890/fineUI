package com.concretepage.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.concretepage.dao.ITaskDAO;
import com.concretepage.entity.Task;
import com.concretepage.service.ITaskService;

@Service
public class TaskServiceImpl implements ITaskService {

	
	@Autowired
	private ITaskDAO dao;
	
	@Override
	public List<Task> getTasks() {
		return dao.getTasks();
	}

	@Override
	public void create(Task task) {
		dao.create(task);
	}

	@Override
	public void update(Task task) {
		dao.update(task);
		
	}

	@Override
	public void delete(Task task) {
	dao.delete(task);
		
	}

}

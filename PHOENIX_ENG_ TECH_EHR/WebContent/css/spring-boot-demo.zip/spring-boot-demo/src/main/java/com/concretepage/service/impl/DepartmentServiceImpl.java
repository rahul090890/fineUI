package com.concretepage.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.concretepage.dao.IDepartmentDAO;
import com.concretepage.entity.Department;
import com.concretepage.service.IDepartmentService;

@Service
public class DepartmentServiceImpl implements IDepartmentService {
	
	@Autowired
	private IDepartmentDAO dao;
	
	@Override
	public List<Department> getDepartments() {
		return dao.getDepartments();
	}

	@Override
	public void create(Department department) {
		dao.create(department);
		
	}

	@Override
	public void update(Department department) {
		dao.update(department);
		
	}

	@Override
	public void delete(Department department) {
		dao.delete(department);
		
	}

}

package com.concretepage.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.concretepage.dao.ITaskDAO;
import com.concretepage.entity.Customer;
import com.concretepage.entity.Department;
import com.concretepage.entity.Task;
@Transactional
@Repository
public class TaskDAOImpl implements ITaskDAO {
	@PersistenceContext	
	private EntityManager entityManager;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Task> getTasks() {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		 CriteriaQuery<Task> criteria = cb.createQuery(Task.class);
		 Root<Task> root = criteria.from(Task.class);
		 criteria.select(root);
		 criteria.orderBy(cb.asc(root.get("taskId")));
		 return entityManager.createQuery(criteria).getResultList();
	}

	@Override
	public void update(Task task) {
		Department dept = entityManager.find(Department.class, task.getDepartment().getDepartmentId());
		task.setDepartment(dept);
		Customer cust = entityManager.find(Customer.class, task.getCustomer().getCustomerId());
		task.setCustomer(cust);
		entityManager.merge(task);
	}

	@Override
	public void create(Task task) {
		entityManager.persist(task);
	}

	@Override
	public void delete(Task task) {
		task = entityManager.find(Task.class, task.getTaskId()); 
		entityManager.remove(task);
		
	}

}

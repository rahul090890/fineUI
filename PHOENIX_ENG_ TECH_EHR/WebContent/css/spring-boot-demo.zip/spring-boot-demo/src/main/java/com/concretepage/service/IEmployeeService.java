package com.concretepage.service;

import java.util.List;

import com.concretepage.entity.Employee;

public interface IEmployeeService {
	
	List<Employee> getEmployees();
	
	List<Employee> getManagers();
	
	void update(Employee employee);
	
	void create (Employee employee);
	
	void delete(Employee employee);
	
	String resetPassword(String employeeId);

}

package com.concretepage.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.concretepage.dao.IGroupCodeValuesDao;
import com.concretepage.entity.GroupCodeValues;
import com.concretepage.service.IReferenceDataService;

@Service
public class ReferenceDataServiceImpl implements IReferenceDataService {

	private final Logger log = LoggerFactory.getLogger(this.getClass());
	
	Map<String, List<GroupCodeValues>> groupCodeValues = new ConcurrentHashMap<String,List<GroupCodeValues>>();
	
	@Autowired
	IGroupCodeValuesDao dao;
	
	@PostConstruct
	@Override
	public Map<String, List<GroupCodeValues>> getGroupCodeValues() {
	if(groupCodeValues.size() == 0) {
		List<GroupCodeValues> listOfgroupCodeValues = loadGroupCodeValues();
		log.info("Loading dropdown values from database");
		for(GroupCodeValues codeValue : listOfgroupCodeValues) {
			String groupName = codeValue.getGroupName();
			if(null == groupCodeValues.get(groupName)) {
				List<GroupCodeValues> list = new ArrayList<GroupCodeValues>();
				list.add(codeValue);
				log.debug(" Adding the group " + groupName + " with the value " + codeValue.toString());
				groupCodeValues.put(groupName, list);
			} else {
				groupCodeValues.get(groupName).add(codeValue);
			}
		}
		log.info("The number of groups added are" + groupCodeValues.size() );
	} 
		return groupCodeValues;
	}

	@Override
	public List<GroupCodeValues> loadGroupCodeValues() {
		return dao.listGroupCodeValues();
	}
	
	

}

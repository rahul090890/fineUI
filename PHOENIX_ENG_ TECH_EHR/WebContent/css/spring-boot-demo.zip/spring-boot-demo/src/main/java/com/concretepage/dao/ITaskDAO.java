package com.concretepage.dao;

import java.util.List;

import com.concretepage.entity.Task;

public interface ITaskDAO {

	List<Task> getTasks();
	void update(Task task);
	void create(Task task);
	void delete(Task task);
}

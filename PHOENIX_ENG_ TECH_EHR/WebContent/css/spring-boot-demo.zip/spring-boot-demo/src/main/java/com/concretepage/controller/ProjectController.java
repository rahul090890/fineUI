package com.concretepage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.concretepage.entity.Project;
import com.concretepage.service.IProjectService;
@CrossOrigin(maxAge = 3600)
@Controller
@RequestMapping("hr/project")
public class ProjectController {

	@Autowired
	private IProjectService service;
	
	@GetMapping("all")
	public ResponseEntity<List<Project>> getProjects() {
		List<Project> projects = service.getProjects();
		return new ResponseEntity<List<Project>>(projects, HttpStatus.OK);
	}
	
	@Transactional(propagation=Propagation.REQUIRED)
	@PostMapping("/create/{projectName}/{customerProjectCode}/{projectType}")
	public ResponseEntity<Void> create(
			@PathVariable("projectName") String projectName,
			@PathVariable("customerProjectCode") String customerProjectCode,
			@PathVariable("projectType") String projectType,
			@PathVariable("projectStatus") String projectStatus
			) {
		Project project = new Project();
		project.setProjectName(projectName);
		project.setCustomerProjectCode(customerProjectCode);
		project.setProjectType(projectType);
		project.setProjectStatus(projectStatus);
		
		service.create(project);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}
	
	@Transactional(propagation=Propagation.REQUIRED)
	@PostMapping("/update/{projectid}/{projectName}/{customerProjectCode}/{projectType}")
	public ResponseEntity<Void> update(
			@PathVariable("projectid") String projectid,
			@PathVariable("projectName") String projectName,
			@PathVariable("customerProjectCode") String customerProjectCode,
			@PathVariable("projectType") String projectType,
			@PathVariable("projectStatus") String projectStatus
			) {
		Project project = new Project();
		project.setProjectid(Integer.parseInt(projectid));
		project.setProjectName(projectName);
		project.setCustomerProjectCode(customerProjectCode);
		project.setProjectType(projectType);
		project.setProjectStatus(projectStatus);
		
		service.update(project);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@DeleteMapping("delete/{projectid}")
	public ResponseEntity<Void> delete (@PathVariable("projectid") String projectid) {
		
		Project project = new Project();
		project.setProjectid(Integer.parseInt(projectid));
		service.delete(project);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
}

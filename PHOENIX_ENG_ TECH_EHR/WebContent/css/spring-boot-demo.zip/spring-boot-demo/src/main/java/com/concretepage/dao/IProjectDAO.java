package com.concretepage.dao;

import java.util.List;

import com.concretepage.entity.Project;

public interface IProjectDAO {

	List<Project> getProjects();
	
	List<Project> findProjectByName(String projectName);
	
	void update(Project project);
	
	void create(Project project);
	
	void delete(Project project);
}

package com.concretepage.service;

import java.util.List;

import com.concretepage.entity.Project;

public interface IProjectService {
	
	List<Project> getProjects();
	
	void create(Project project);
	
	void update(Project project);
	
	void delete(Project project);

}

package com.concretepage.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.concretepage.dao.IProjectDAO;
import com.concretepage.entity.Project;
import com.concretepage.service.IProjectService;

@Service
public class ProjectServiceImpl implements IProjectService {

	@Autowired
	private IProjectDAO dao;
	@Override
	public List<Project> getProjects() {
		return dao.getProjects();
	}
	@Override
	public void create(Project project) {
		dao.create(project);
		
	}
	@Override
	public void update(Project project) {
		dao.update(project);
		
	}
	@Override
	public void delete(Project project) {
		dao.delete(project);
		
	}

}

package com.concretepage.dao;

import java.util.List;

import com.concretepage.entity.GroupCodeValues;

public interface IGroupCodeValuesDao {
	
	List<GroupCodeValues> listGroupCodeValues();

}

package com.concretepage.exception;

public class HRException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9090319487778410159L;

	public HRException(String message) {
		super(message);
	}

}

package com.concretepage.dto;

public class TimsheetSummaryDTO {
	
	private String employeeId;
	private String employeeFirstName;
	private String employeeLastName;
	private String weekStartDate;
	private String weekeEndDate;
	private Float hours;
	private String Status;
	
	

}

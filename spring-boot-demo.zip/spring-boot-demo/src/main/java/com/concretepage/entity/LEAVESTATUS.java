package com.concretepage.entity;

public enum LEAVESTATUS {
	PENDING_APPROVAL,
	APPROVED,
	REJECTED
}

package com.concretepage.entity;

public enum TimesheetStatus {

	DRAFT,
	SUBMITTED,
	APPROVED,
	REJECTED
	
}

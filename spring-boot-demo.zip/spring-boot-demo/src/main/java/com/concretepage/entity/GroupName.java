package com.concretepage.entity;

public enum GroupName {
	employeeStatus,
	customerProgramType,
	Location,
	ProjectType,
	ProjectStatus,
	employeeType,
	leaveType

}
